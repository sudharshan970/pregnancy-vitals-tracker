import React from 'react';
import { VitalsEntry } from '../types';
import { formatDistanceToNow } from 'date-fns';

interface VitalsListProps {
  vitals: VitalsEntry[];
}

export function VitalsList({ vitals }: VitalsListProps) {
  return (
    <div className="space-y-4">
      {vitals.map((entry) => (
        <div
          key={entry.id}
          className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
        >
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-500">
              {formatDistanceToNow(entry.timestamp, { addSuffix: true })}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Blood Pressure</p>
              <p className="text-lg font-semibold">
                {entry.bloodPressureSys}/{entry.bloodPressureDia} mmHg
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Weight</p>
              <p className="text-lg font-semibold">{entry.weight} kg</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Baby Kicks</p>
              <p className="text-lg font-semibold">{entry.babyKicksCount}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}