import React, { useState } from 'react';
import { X } from 'lucide-react';
import { VitalsEntry } from '../types';

interface AddVitalsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (entry: Omit<VitalsEntry, 'id' | 'timestamp'>) => void;
}

export function AddVitalsDialog({ isOpen, onClose, onSubmit }: AddVitalsDialogProps) {
  const [formData, setFormData] = useState({
    bloodPressureSys: '',
    bloodPressureDia: '',
    weight: '',
    babyKicksCount: '',
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      bloodPressureSys: Number(formData.bloodPressureSys),
      bloodPressureDia: Number(formData.bloodPressureDia),
      weight: Number(formData.weight),
      babyKicksCount: Number(formData.babyKicksCount),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Add Vitals Entry</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={24} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Systolic BP
              </label>
              <input
                type="number"
                value={formData.bloodPressureSys}
                onChange={(e) =>
                  setFormData({ ...formData, bloodPressureSys: e.target.value })
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Diastolic BP
              </label>
              <input
                type="number"
                value={formData.bloodPressureDia}
                onChange={(e) =>
                  setFormData({ ...formData, bloodPressureDia: e.target.value })
                }
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Weight (kg)
            </label>
            <input
              type="number"
              step="0.1"
              value={formData.weight}
              onChange={(e) =>
                setFormData({ ...formData, weight: e.target.value })
              }
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Baby Kicks Count
            </label>
            <input
              type="number"
              value={formData.babyKicksCount}
              onChange={(e) =>
                setFormData({ ...formData, babyKicksCount: e.target.value })
              }
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Save Vitals
          </button>
        </form>
      </div>
    </div>
  );
}