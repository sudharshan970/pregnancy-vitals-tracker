export interface VitalsEntry {
  id: string;
  timestamp: number;
  bloodPressureSys: number;
  bloodPressureDia: number;
  weight: number;
  babyKicksCount: number;
}

export interface NotificationPermission {
  granted: boolean;
}