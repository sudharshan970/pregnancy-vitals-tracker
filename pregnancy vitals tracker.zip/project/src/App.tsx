import React, { useState, useEffect } from 'react';
import { PlusCircle, Bell } from 'lucide-react';
import { VitalsList } from './components/VitalsList';
import { AddVitalsDialog } from './components/AddVitalsDialog';
import { useNotifications } from './hooks/useNotifications';
import { VitalsEntry } from './types';

function App() {
  const [vitals, setVitals] = useState<VitalsEntry[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { permission, requestPermission, scheduleNotification } = useNotifications();

  useEffect(() => {
    const savedVitals = localStorage.getItem('vitals');
    if (savedVitals) {
      setVitals(JSON.parse(savedVitals));
    }
  }, []);

  const handleAddVitals = (entry: Omit<VitalsEntry, 'id' | 'timestamp'>) => {
    const newEntry: VitalsEntry = {
      ...entry,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
    };

    const updatedVitals = [newEntry, ...vitals];
    setVitals(updatedVitals);
    localStorage.setItem('vitals', JSON.stringify(updatedVitals));
    scheduleNotification();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Pregnancy Vitals Tracker</h1>
          <div className="flex gap-2">
            {!permission.granted && (
              <button
                onClick={requestPermission}
                className="flex items-center gap-2 bg-gray-100 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-200"
              >
                <Bell size={20} />
                Enable Notifications
              </button>
            )}
            <button
              onClick={() => setIsDialogOpen(true)}
              className="flex items-center gap-2 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700"
            >
              <PlusCircle size={20} />
              Add Vitals
            </button>
          </div>
        </div>

        {vitals.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">No vitals recorded yet. Click "Add Vitals" to get started.</p>
          </div>
        ) : (
          <VitalsList vitals={vitals} />
        )}

        <AddVitalsDialog
          isOpen={isDialogOpen}
          onClose={() => setIsDialogOpen(false)}
          onSubmit={handleAddVitals}
        />
      </div>
    </div>
  );
}

export default App;