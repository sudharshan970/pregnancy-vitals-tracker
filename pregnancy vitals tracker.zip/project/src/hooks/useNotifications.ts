import { useState, useEffect } from 'react';
import { NotificationPermission } from '../types';

export function useNotifications() {
  const [permission, setPermission] = useState<NotificationPermission>({
    granted: false,
  });

  useEffect(() => {
    if (!('Notification' in window)) {
      return;
    }

    if (Notification.permission === 'granted') {
      setPermission({ granted: true });
    }
  }, []);

  const requestPermission = async () => {
    if (!('Notification' in window)) {
      return;
    }

    const result = await Notification.requestPermission();
    setPermission({ granted: result === 'granted' });
  };

  const scheduleNotification = () => {
    if (!permission.granted) return;

    setTimeout(() => {
      new Notification('Time to log your vitals!', {
        body: 'Stay on top of your health. Please update your vitals now!',
      });
    }, 5 * 60 * 60 * 1000); // 5 hours
  };

  return { permission, requestPermission, scheduleNotification };
}